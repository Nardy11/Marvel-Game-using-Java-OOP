package model.world;

public enum Condition {
	ACTIVE, KNOCKEDOUT, INACTIVE,ROOTED
}
